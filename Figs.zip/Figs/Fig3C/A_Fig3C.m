%addpath('src/')
Red_color = [0.827 0.51 0.518];%#d38284
Blue_color = [0.392 0.573 0.663];%#6492A9

file = dir('raw_data_for_plot/*.xlsx');
ind  =1;
filename = ['raw_data_for_plot/' file(ind).name];
name = file(ind).name(1:find(file(ind).name=='.',1,'last')-1);
[values,~]=xlsread(filename,1);
values(~any(~isnan(values),2),:)=[];
result = values(:,[1,6,8]);

set(0,'DefaultAxesFontName', 'Arial')
set(0,'DefaultTextFontname', 'Arial')
Label_Size = 28;
Line_Width = 5;
alpha = 0.05;
x = result(:,1);
y = result(:,2);
mdl = fitlm(x,y);
xhat = linspace(min(x),max(x),100)';
% [yhat,yci] = predict(mdl,xhat,'Prediction','observation');
[yhat,yci] = predict(mdl,xhat,'Alpha',alpha);
f = figure('Renderer', 'painters', 'Position', [10 10 540 400]);
yyaxis right
plot(xhat,yhat,'Color',Red_color,'LineStyle','-','LineWidth',Line_Width);
hold on;
plot(xhat,yci,'Color',Red_color,'LineStyle','--','LineWidth',Line_Width);
set(gca,'ycolor',Red_color);
ylabel('Molecule');

yyaxis left
y2 = result(:,3);
mdl2 = fitlm(x,y2);
% [yhat2,yci2] = predict(mdl2,xhat,'Prediction','observation');
[yhat2,yci2] = predict(mdl2,xhat,'Alpha',alpha);
plot(xhat,yhat2,'Color',Blue_color,'LineStyle','-','LineWidth',Line_Width);
hold on;
plot(xhat,yci2,'Color',Blue_color,'LineStyle','--','LineWidth',Line_Width);

ylabel('Molecule/\mum^2');
set(gca,'ycolor',Blue_color);
set(gca,'FontSize',Label_Size);
set(gca,'TickDir','out');
set(gca,'TickLength',[0.03, 0.01]);
set(gca,'Box','off');
xlim([min(x),max(x)]);
h = gca;
h.LineWidth = Line_Width;
h.XTick = 1:1:4;
h.XAxis.MinorTick = 'on';
h.XAxis.MinorTickValues = 1:0.5:5;
xlabel('Length(\mum)');
% title('+-100nm Fraction')
set(gca, 'FontName', 'Arial');
print(f,'Fig3C.tif','-dtiffn');