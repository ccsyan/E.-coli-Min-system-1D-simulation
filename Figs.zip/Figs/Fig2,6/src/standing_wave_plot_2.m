function standing_wave_plot_2(C)
    set(0,'DefaultAxesFontName', 'Arial')
    set(0,'DefaultTextFontname', 'Arial')
    Label_Size = 28;
    Line_Width = 5;
    alpha = 0.05;
    cell_num = C.cell_num;
    Red_color = [0.827 0.51 0.518];%#d38284
    Blue_color = [0.392 0.573 0.663];%#6492A9
    cmap = [Red_color;Red_color;0 0 0;Blue_color;Blue_color];
    Intensity = C.interp_intensity;
    Intensity(:,3) = Intensity(:,3)+C.min_intensity;
    f = figure('Renderer', 'painters', 'Position', [10 10 1600 200]);
    grid = [0.1,0.25,0.5,0.75,0.9];

    for i = 1:5
        hold all;
        temp = Intensity(Intensity(:,2)==grid(i),:);
        display_name = sprintf('%.2f',temp(1,2));
        plot(temp(:,1)*12,temp(:,3),'Color',cmap(i,:),'DisplayName',display_name,'LineWidth',Line_Width);
%         fprintf(1,'%.2f: %d\n',temp(1,2),color_index);
    end
    legend('off');
    set(gca,'FontSize',Label_Size);
    h = gca;
    h.LineWidth = Line_Width;
    h.XTick = 0:100:600;
    xlabel('Time (s)');
    ylabel('Intensity (au)');
end