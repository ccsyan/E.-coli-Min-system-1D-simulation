function result = find_index_from_cell_num(C,cell_nums)
    result = zeros(1,numel(cell_nums));
    for i = 1:numel(C)
        num = C(i).cell_num;
        if any(cell_nums ==num)
            result(cell_nums == num) = i;
        end
    end
end