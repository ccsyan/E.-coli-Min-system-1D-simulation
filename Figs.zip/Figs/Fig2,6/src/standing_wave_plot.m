function standing_wave_plot(C,filename)
    cell_num = C.cell_num;
    cmap = colormap(lines);
    Intensity = C.interp_intensity;
    interp_width = C.interp_width;
    num = 1/interp_width + 1;
    mid_num = (num+1)/2;
    figure;
    subplot(2,1,1);
    color_index = 1;
    for i = 2:2:(mid_num-1)
        hold all;
        temp = Intensity(Intensity(:,2)==Intensity(i,2),:);
        display_name = sprintf('%.2f',temp(1,2));
        plot(temp(:,1),temp(:,3),'Color',cmap(color_index,:),'DisplayName',display_name);
%         fprintf(1,'%.2f: %d\n',temp(1,2),color_index);
        color_index = color_index + 1;
    end
    legend('-DynamicLegend');
    title(sprintf('%s, cell num : %d, Top half',filename,cell_num),'FontSize',20)
    subplot(2,1,2);
    color_index = color_index - 1;
    for i = (mid_num+1):2:num
        hold all;
        temp = Intensity(Intensity(:,2)==Intensity(i,2),:);
        display_name = sprintf('%.2f',temp(1,2));
        plot(temp(:,1),temp(:,3),'Color',cmap(color_index,:),'DisplayName',display_name);
%         fprintf(1,'%.2f: %d\n',temp(1,2),color_index);
        color_index = color_index - 1;
    end
    legend('-DynamicLegend');
    title(sprintf('%s, cell num : %d, Bottom half',filename,cell_num),'FontSize',20)
end