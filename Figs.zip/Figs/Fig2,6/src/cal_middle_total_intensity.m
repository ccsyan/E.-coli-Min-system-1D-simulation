function [x,y] = cal_middle_total_intensity(raw_intensity,percent)
    time_index = unique(raw_intensity(:,1));
    total_intensity = zeros(numel(time_index),2);
    thres_pos = [0.5 - percent,0.5 + percent];
    
    for i = 1:numel(time_index)
        total_intensity(i,1) = time_index(i);
        temp = raw_intensity(raw_intensity(:,1)== time_index(i),2:3);
        if percent ~= 0.5
            thres_inten= interp1(temp(:,1),temp(:,2),thres_pos);
            temp = temp(temp(:,1)>thres_pos(1) & temp(:,1) < thres_pos(2),:);
            thres_data = [thres_pos',thres_inten'];
            temp = [thres_data;temp];
        end
        temp = sortrows(temp,1);
        ctemp = circshift(temp,1);
        height = temp(2:end,1) - ctemp(2:end,1);
        weight = temp(2:end,2) + ctemp(2:end,2);
        total_intensity(i,2) = height' * weight/2;
    end

    x = total_intensity(:,1);
    y =total_intensity(:,2);
%     plot(x,y);
end