function [f] = get_exp(data,mu)
    expEqn = ['a*exp(-c*abs(x-' num2str(round(mu,2)) '))'];
%     expEqn = ['a*exp(-c*abs(x-d))'];
    f = fit(data(:,1),data(:,2),expEqn,'StartPoint', [max(data(:,2)) 0.1]);
end