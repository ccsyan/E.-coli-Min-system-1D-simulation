classdef particles
%============================================
% Properties
%============================================
%     cell_num : int (default=-1)
%         The cell number marked in excel file.
% 
%     length : int (default=0)
%         The cell length provided in excel file.
% 
%     intensity: array-like, shape=[time steps, normalized positions, intensities]
%         The intensity recorded in excel file.
% 
%     interp_intensity : 3-D array
%         The interpolated intensity using linear method.
% 
%     interp_width : int (default=0.05)
%         The interval to perform interpolation.
% 
%     invert_bol : 1-D array 
%         1  -- red line
%         0  -- blue line
%        -1  -- gray line
% 
%     normal_func : cell, shape=(2, 1);
%         exponential fitting curves calculated from Normalized length with
%            {function for red line;
%             function for blue line}
% 
%     unnormal_func : cell, shape=(2, 1);
%         exponential fitting curves calculated from Unnormalized length with
%            {function for red line;
%             function for blue line}
% 
%     kern_func : cell, shape=(2, 1);
%         functions calculated from Unnormalized length by using kernel smoothing
%            {function for red line;
%             function for blue line}
% 
%     normal_lambda : int (default=-1)
%         The estimated lambda using exponential curve fitting with raw
%         cell length.
% 
%     unnormal_lambda : int (default=-1)
%         The estimated lambda using exponential curve fitting with
%         normalized cell length.
% 
%     decay_lambda : int (default=-1)
%         The estimated lambda using exponential curve fitting after the
%         correction to photobleaching with normalized cell length.
%     
    
    
    
    properties
        cell_num=-1;
        length=0;
        intensity;
        interp_intensity =[];
        interp_width =0.05;
        invert_bol=[];
        normal_func = cell(2,1);
        unnormal_func = cell(2,1);
        normal_lambda = -1;
        unnormal_lambda = -1;
        kern_func = cell(2,1);
        crest = [0,0];
        decay_lambda = -1;
        I_ratio = 0;
        min_intensity = 0;
        I_min = 0;
        I_max = 0;
    end
    methods
        %=====================================
        %compute blue and red lines(invert_bol);
        function [obj,slope]=cal_sep(obj)
            inten = obj.intensity;

            T = unique(inten(:,1));
            slope = zeros(numel(T),1);
            %compute slopes
            for j=1:numel(T)
                i = T(j);
                temp_value = inten(inten(:,1)==i,2:3);
                s_parameter = ceil(numel(temp_value(:,1))/10)+2;
                s_value = smoothdata(temp_value(:,2),'movmean',s_parameter);
                slope(j)=diff(interp1(temp_value(:,1),s_value,[0.2,0.8]));
            end

            temp_bol = ones(1,numel(slope))*-1;
            cluster = kmeans(slope,2);
            if mean(slope(cluster==1))<mean(slope(cluster==2))
                cluster = (3-cluster);
            end
            limit1 = quantile(slope(cluster==1),0.25);
            limit2 = quantile(slope(cluster==2),0.75);
            temp_bol(slope>limit1)=1;
            temp_bol(slope<limit2)=0;

            obj.invert_bol = temp_bol;
        end
        %=====================================
        %compute interp
        function obj= cal_interp(obj)
            width = obj.interp_width;
            
            data_point = [];
            
            inten = obj.intensity;
            T = unique(inten(:,1));
            for j = 1:numel(T)
                i = T(j);

                temp_value = inten(inten(:,1)==i,2:3);
                s_parameter = ceil(numel(temp_value(:,1))/10)+2;
                s_value = smoothdata(temp_value(:,2),'movmean',s_parameter);
                xx = 0:width:1;
                yy = interp1(temp_value(:,1),s_value,xx);
                temp_data = [repmat(i,numel(xx),1),xx',yy'];
                data_point = [data_point;temp_data];
            end
            if true
                sum_data = zeros(numel(T),2);
                for j=1:numel(T)
                    k = T(j);
                    sum_data(j,1)=k;
                    sum_data(j,2) = mean(data_point(data_point(:,1)==k,3));
                end
                expEqn = 'a*exp(-b*x)';
                f = fit(sum_data(:,1),sum_data(:,2),expEqn,...
                    'StartPoint',[max(sum_data(:,2)),0.05]);
                data_point(:,3) = data_point(:,3)./exp(-f.b.*data_point(:,1));
            
%                 mi = max(data_point(:,3));
%                 ni = min(data_point(:,3));
%                 data_point(:,3) = (data_point(:,3)-ni)/(mi-ni);
                obj.decay_lambda = f.b;

% 
%                 for j=1:numel(T)
%                     k = T(j);
%                     k_index = data_point(:,1)==k;
%                     data_point(k_index,3) = data_point(k_index,3)/sum_data(j,2)*mean(sum_data(:,2));
%                 end
            end
            obj.interp_intensity = data_point;
        end
        %=====================================
        %compute functions
        function obj = cal_func(obj)
            
            inten = obj.interp_intensity;
            T = unique(inten(:,1));
            xx = 0:obj.interp_width:1;
            invert_bol = obj.invert_bol;
            fun = @(x) invert_bol(find(T==x));
            A = [arrayfun(fun,inten(:,1)),inten(:,2:3)];
            
            data_red = A(A(:,1)==1,2:3);
            data_blue = A(A(:,1)==0,2:3);
            %red line
            r1 = ksrlin(data_red(:,1),data_red(:,2),0.05);
            %blue line
            r2 = ksrlin(data_blue(:,1),data_blue(:,2),0.05);
            [~,ind_red] = max(r1.f);
            [~,ind_blue] =max(r2.f);
            
            nf1 = get_exp(data_red,r1.x(ind_red));
            nf2 = get_exp(data_blue,r2.x(ind_blue));
            uf1 = get_exp([data_red(:,1)*obj.length,...
                data_red(:,2)], r1.x(ind_red)*obj.length);
            uf2 =  get_exp([data_blue(:,1)*obj.length,...
                data_blue(:,2)],r2.x(ind_blue)*obj.length);
            n1 = sum(invert_bol==1);
            n2 = sum(invert_bol==0);
            nlambda = (nf1.c*n1+nf2.c*n2)/(n1+n2);
            ulambda = (uf1.c*n1+uf2.c*n2)/(n1+n2);
            
            obj.normal_func = {nf1;nf2};
            obj.unnormal_func = {uf1;uf2};
            obj.kern_func = {r1;r2};
            obj.normal_lambda = nlambda;
            obj.unnormal_lambda = ulambda;
            obj.crest = sort([r1.x(ind_red),r2.x(ind_blue)]);
        end
        %=====================================
        %compute theta
        function obj = cal_I_ratio(obj)
            [f1,f2] = deal(obj.normal_func{:});
            [r1,r2] = deal(obj.kern_func{:});
            xx = 0:0.05:1;
            max_amplifier = max(f1.a,f2.a);
            dif = (f1(xx)-f2(xx))/max_amplifier;
            ind = find(dif>=0,1,'first');
            if dif(ind)==0
                crit_p = ind;
            else
                crit_p = (xx(ind-1)*abs(dif(ind))+xx(ind)*abs(dif(ind-1)))/sum(abs(dif(ind-1:ind)));
            end
            obj.I_ratio = f1(crit_p)/max_amplifier;
            obj.I_min = f1(crit_p);
            obj.I_max = max_amplifier;
        end
        %=====================================
        %draw raw lines
        function draw_raw(obj,interp_flag)
            if nargin ==1
                inten = obj.intensity;
            else
                if interp_flag ==1
                    inten = obj.intensity;
                else
                    inten = obj.interp_intensity;
                end
            end
            T = unique(inten(:,1));
            hold on;
            %parameters
            opacity = .5;
            marksize = 2;
            markstyle = '.-';
            
            for j = 1:numel(T)
                i = T(j);
                temp_value = inten(inten(:,1)==i,2:3);
                if obj.invert_bol(j)==-1%gray
                    plot(temp_value(:,1),temp_value(:,2),'-','Color',[0,0,0,.1],'MarkerSize',marksize,'LineWidth',2);
                elseif obj.invert_bol(j)==1%red
                    plot(temp_value(:,1),temp_value(:,2),markstyle,'Color',[1,0,0,opacity],'MarkerSize',marksize,'LineWidth',2);
                elseif obj.invert_bol(j)==0%blue
                    plot(temp_value(:,1),temp_value(:,2),markstyle,'Color',[0,0,1,opacity],'MarkerSize',marksize,'LineWidth',2);
                end

%                  plot(temp_value(:,1),temp_value(:,2),markstyle,'Color',[0,0,0,opacity],'MarkerSize',marksize,'LineWidth',2);
            end
        end
        %=====================================
        %display mean plot
        function draw_mean(obj,color)
            if nargin==1
                color = 'g';
            end
            inten = obj.interp_intensity;
            xx = 0:obj.interp_width:1;
            y_mean = mean(reshape(inten(:,3),numel(xx),[]),2);
            p_1 = plot(xx,y_mean,...
                            'LineWidth',3,'Color',color,'DisplayName','mean');
%             ylim([0 1.5]);
            xlabel('Normalized Position');
            ylabel('Intensity');
            title(['cnum: ' num2str(obj.cell_num)...
                ' length: ' num2str(round(obj.length,2))...
                ' \lambda: ' num2str(round(obj.normal_lambda,2))])
            legend(p_1);
        end
        %=====================================
        %fitted plot
        function draw_nfit(obj)
            inten = obj.interp_intensity;
            T = unique(inten(:,1));
            hold on;
            %parameters
            opacity = 0.2;
            marksize = 2;
            markstyle = '.-';
            
            
            for j = 1:numel(T)
                i = T(j);
                temp_value = inten(inten(:,1)==i,2:3);
                if obj.invert_bol(j)==-1%gray
                    plot(temp_value(:,1),temp_value(:,2),'-','Color',[0,0,0,0.1]);
                elseif obj.invert_bol(j)==1%red
                    plot(temp_value(:,1),temp_value(:,2),markstyle,'Color',[1,0,0,opacity],'MarkerSize',marksize);
                elseif obj.invert_bol(j)==0%blue
                    plot(temp_value(:,1),temp_value(:,2),markstyle,'Color',[0,0,1,opacity],'MarkerSize',marksize);
                end
            end
            [r1,~] = deal(obj.kern_func{:});
            [f1,f2] = deal(obj.normal_func{:});
            plot(r1.x,f1(r1.x),'g-','HandleVisibility','off','LineWidth',2);
            plot(r1.x,f2(r1.x),'g-','HandleVisibility','off','LineWidth',2);
            xlabel('Normalized Position');
            ylabel('Intensity');
            title(['cnum: ' num2str(obj.cell_num) ' len: '...
                num2str(round(obj.length,2)) ' \lambda: '...
                        num2str(round(obj.normal_lambda,2))])
        end
        %=====================================
        %fitted plot
        function draw_ufit(obj)
            inten = obj.interp_intensity;
            len = obj.length;
            T = unique(inten(:,1));
            hold on;
            %parameters
            opacity = 0.2;
            marksize = 2;
            markstyle = '.-';
            
            
            for j = 1:numel(T)
                i = T(j);
                temp_value = inten(inten(:,1)==i,2:3);
                temp_value(:,1) = (temp_value(:,1)-0.5)*len;
                if obj.invert_bol(j)==-1%gray
                    plot(temp_value(:,1),temp_value(:,2),'-','Color',[0,0,0,0.1]);
                elseif obj.invert_bol(j)==1%red
                    plot(temp_value(:,1),temp_value(:,2),markstyle,'Color',[1,0,0,opacity],'MarkerSize',marksize);
                elseif obj.invert_bol(j)==0%blue
                    plot(temp_value(:,1),temp_value(:,2),markstyle,'Color',[0,0,1,opacity],'MarkerSize',marksize);
                end
            end
            [r1,~] = deal(obj.kern_func{:});
            [f1,f2] = deal(obj.unnormal_func{:});
            xx = (r1.x-0.5)*len;
            plot(xx,f1(r1.x*len),'g-','HandleVisibility','off','LineWidth',2);
            plot(xx,f2(r1.x*len),'g-','HandleVisibility','off','LineWidth',2);
            xlabel('Position');
            ylabel('Intensity');
            title(['cnum: ' num2str(obj.cell_num) ' len: '...
                num2str(round(obj.length,2)) ' \lambda: '...
                        num2str(round(obj.normal_lambda,2))])
            xlim([min(xx) max(xx)])
        end
        %=====================================
        %critical points with fitted plot
        function draw_crit(obj)
            inten = obj.interp_intensity;
            T = unique(inten(:,1));
            hold on;
            %parameters
            opacity = 0.2;
            marksize = 2;
            markstyle = '-';
            
            
            for j = 1:numel(T)
                i = T(j);
                temp_value = inten(inten(:,1)==i,2:3);
                if obj.invert_bol(j)==-1%gray
                    plot(temp_value(:,1),temp_value(:,2),'-','Color',[0,0,0,0.1]);
                elseif obj.invert_bol(j)==1%red
                    plot(temp_value(:,1),temp_value(:,2),markstyle,'Color',[1,0,0,opacity]);
                elseif obj.invert_bol(j)==0%blue
                    plot(temp_value(:,1),temp_value(:,2),markstyle,'Color',[0,0,1,opacity]);
                end
            end
            [r1,r2] = deal(obj.kern_func{:});
            [f1,f2] = deal(obj.normal_func{:});
            plot(r1.x,f1(r1.x),'g-','HandleVisibility','off','LineWidth',2);
            plot(r1.x,f2(r1.x),'g-','HandleVisibility','off','LineWidth',2);
            xlabel('Normalized Position');
            ylabel('Intensity');
            title(['cnum: ' num2str(obj.cell_num) ' len: '...
                num2str(round(obj.length,2)) ' \lambda: '...
                        num2str(round(obj.normal_lambda,2))])
        end
        %=====================================
        %display 3d mean plot
        function [xx,y_mean]=draw_3dmean(obj,z,color)
            if nargin==2
                color = 'g';
            end
            inten = obj.interp_intensity;
            xx = 0:obj.interp_width:1;
            y_mean = mean(reshape(inten(:,3),numel(xx),[]),2);
            p_1 = plot3(repmat(z,numel(xx),1),xx,y_mean,...
                            'LineWidth',5,'Color',color);
            
%             ylabel('Normalized Length');
%             zlabel('Normalized Intensity');
        end
        %=====================================
        %get 3d mean data points
        function [xx,y_mean]=get_3dmean(obj)
            inten = obj.interp_intensity;
            xx = 0:obj.interp_width:1;
            y_mean = mean(reshape(inten(:,3),numel(xx),[]),2);
        end
    end
end