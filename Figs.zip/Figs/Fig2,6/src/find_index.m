function [index,display_name] = find_index(name,PatternCell)
    NumPatternCat = numel(PatternCell);
    index = zeros(1,NumPatternCat);
    if ~contains(name,'_ex_')
        for i = 1:NumPatternCat
            index(i) = contains_string(name,PatternCell{i});
        end
        display_name = name;
    else
        target_index = strfind(name,'_ex_');
        display_name = [name(1:(target_index-1)),name(target_index+5:end)];
    end
    
end