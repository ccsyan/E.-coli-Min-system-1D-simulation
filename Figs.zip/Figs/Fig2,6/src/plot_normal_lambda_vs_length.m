function plot_normal_lambda_vs_length(C)
    set(0,'DefaultAxesFontName', 'Arial')
    set(0,'DefaultTextFontname', 'Arial')
    Line_Width = 3;
    Label_Size = 22;
    num = numel(C);
    summary = zeros(num,3);
    for i =1:num
        summary(i,1) = C(i).length;
        summary(i,2) = C(i).unnormal_lambda;
        summary(i,3) = C(i).normal_lambda;
    end
    scatter(1./summary(:,1),summary(:,2),35,'filled','MarkerFaceColor',[0 0.5 0.5],'MarkerEdgeColor','b');
    mdl = fitlm(1./summary(:,1),summary(:,2));
    hold on;
    plot(1./summary(:,1),mdl.predict,'r','LineWidth',4);
    plot([1/2.85 1/2.85],[0 mdl.predict(1/2.85)],'r--','LineWidth',Line_Width);
    plot([0,1/2.85],[mdl.predict(1/2.85) mdl.predict(1/2.85)],'r--','LineWidth',Line_Width);
    text(1/2.85+0.02,mdl.predict(1/2.85)/2,{'2.85'},'Color','red','FontSize',22);
    text(0.05,mdl.predict(1/2.85)+0.1,[ sprintf('%.2f',mdl.predict(1/2.85))],'Color','red','FontSize',22);
    set(gca,'FontSize',Label_Size);
    xlim([0,0.8]);
    ylim([0,1.5]);
    xticks(0:0.2:0.8);
    yticks(0:0.5:1.5);
    h = gca;
    h.LineWidth = 2;
    h.XAxis.MinorTick = 'on';
    h.XAxis.MinorTickValues = 0:0.1:0.8;
    h.YAxis.MinorTick = 'on';
    h.YAxis.MinorTickValues = 0:0.25:1.5;
    xlabel('Length^{-1} (\mum^{-1})');
    ylabel('\lambda');
    legend('off');
    hYLabel = get(gca,'YLabel');
    set(hYLabel,'rotation',0,'VerticalAlignment','middle')
end
    