function [result] = Draw_Exp_Decay_Fit(X)
    set(0,'DefaultAxesFontName', 'Arial')
    set(0,'DefaultTextFontname', 'Arial')
    Line_Width = 3;
    Label_Size = 22;
    scatter(X(:,1),X(:,2),35,'filled','MarkerFaceColor',[0 0.5 0.5],'MarkerEdgeColor','b');
    hold on;
    mdl = fit(X(:,1),X(:,2),'exp(b*x)','StartPoint',0);
    mdl_yy = mdl(X(:,1));
    plot(X(:,1),mdl_yy,'r','LineWidth',4);
    Half_Point = log(0.5)/mdl.b;
%     Median_Length = log(round(mdl(median(X(:,1))),2))/mdl.b;
    Median_Length = median(X(:,1));

    scatter(Half_Point,mdl(Half_Point),15,'filled');
    plot([0 Half_Point],[mdl(Half_Point) mdl(Half_Point)],'r--','LineWidth',Line_Width);
    plot([Half_Point Half_Point],[0 mdl(Half_Point)],'r--','LineWidth',Line_Width);
    plot([Median_Length Median_Length],[0,mdl(Median_Length)],'k--','LineWidth',Line_Width);
    plot([0 Median_Length],[mdl(Median_Length),mdl(Median_Length)],'k--','LineWidth',Line_Width);

    if Half_Point < Median_Length
        text(Half_Point-1.1,0.1,sprintf('%.3f',Half_Point),'Color','red','FontSize',Label_Size);
        text(Median_Length + 0.2,0.1,sprintf('%.3f',Median_Length),'Color','black','FontSize',Label_Size);
        text(0.5,mdl(Median_Length) -0.05,sprintf('%.3f',mdl(Median_Length)),'Color','black','FontSize',Label_Size);
    else
        text(Half_Point + 0.2,0.1,sprintf('%.3f',Half_Point),'Color','red','FontSize',Label_Size);
        text(Median_Length - 1.1,0.1,sprintf('%.3f',Median_Length),'Color','black','FontSize',Label_Size);
        text(0.5,mdl(Median_Length) +0.05,sprintf('%.3f',mdl(Median_Length)),'Color','black','FontSize',Label_Size);
    end
%         fprintf(1,'%f\n',mdl.a);
%         plot(fitlm(temp_lam(:,1),temp_lam(:,2)));
    set(gca,'FontSize',Label_Size);
    ylim([0,1]);
    xlim([0,6]);
    xticks(0:1:6);
    yticks(0:0.2:1);
    h = gca;
    h.LineWidth = 2;
    h.XAxis.MinorTick = 'on';
    h.XAxis.MinorTickValues = 0:0.5:6;
    h.YAxis.MinorTick = 'on';
    h.YAxis.MinorTickValues = 0:0.1:1;
    xlabel('Length');
    ylabel('Lowest Ratio');
    legend('off');
    result = {[Half_Point,0.5],[Median_Length,mdl(Median_Length)]};
end