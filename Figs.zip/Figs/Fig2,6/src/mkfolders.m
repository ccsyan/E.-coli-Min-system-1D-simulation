function mkfolders(destination,subfolder)
%mkfolder Make new folders under destination
%   mkfolder(destination,subfolder) make new folders with names in
%   subfolder under destination.
%
    if ~isempty(destination)
        if ~exist(destination,'dir')
            mkdir(destination);
%             fprintf(1,'\t\t%-32s \thas been created.\n',destination(1:end-1));
        else
%             fprintf(1,'\t\t%-32s \texists already.\n',destination(1:end-1));
        end
    end
    for i = 1:numel(subfolder)
        foldername = [destination,subfolder{i}];
        if ~exist(foldername,'dir')
            mkdir(foldername);
%             fprintf(1,'\t\t�u%-30s \thas been created.\n',subfolder{i});
        else
%             fprintf(1,'\t\t�u%-30s \texists already.\n',subfolder{i});
        end
    end
end

