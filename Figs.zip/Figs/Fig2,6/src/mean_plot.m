function mean_plot(C,Show_Lowest_Pt,Middle_IRatio_Length)
    Cell_Length = [];
    Intensity=[];
    I_Ratio_Pos=[];
    Label_Size = 22;
    color_range = linspace(0.4,1,256);
    %M = 128;
    %R = interp1([0.4 0.7 1],[0 1 1], color_range);
    %G = interp1([0.4 0.7 1],[0 1 0], color_range);
    %B = interp1([0.4 0.7 1],[1 0 0], color_range);
    %map = [R' G' B'];
    %map = colormap('autumn');
    map = colormap('jet');
    map(1,:) = [0.5 0.5 0.5];
    %Set font name for figures
    set(0,'DefaultAxesFontName', 'Arial');
    set(0,'DefaultTextFontName', 'Arial');
    %Get largest Length
%     Max_Length = 0;
%     for i =1:numel(C)
%         if Max_Length < C(i).length
%             Max_Length = C(i).length;
%         end
%     end
    Max_Length = 5.4619;%file(6) max length
    xx = linspace(-Max_Length/2,Max_Length/2,501);
    
    for i=1:numel(C)
        temp_len = C(i).length;  
        [Raw_xx,Raw_yy]=C(i).get_3dmean;
    %     plot3(repmat(len,numel(xx),1),xx,yy);
        Raw_xx = temp_len*(Raw_xx-0.5);
        Raw_yy = Raw_yy/max(Raw_yy);
        Valid_Interp = (xx>=-temp_len/2) & (xx<= temp_len/2);
        Interp_yy = zeros(numel(xx),1);
        Interp_yy(~Valid_Interp) = NaN;
        Interp_yy(Valid_Interp) = interp1(Raw_xx,Raw_yy,xx(Valid_Interp),'pchip');
        Cell_Length = [Cell_Length;temp_len];
        Intensity = [Intensity,Interp_yy];
        [~,pk_Index] = findpeaks(Interp_yy,'MinPeakProminence',0.1);
        if numel(pk_Index)>=2
            [~,I_Ratio_Index] = min(Interp_yy(pk_Index(1):pk_Index(end)));
            I_Ratio_Pos =[I_Ratio_Pos, xx(I_Ratio_Index+pk_Index(1)-1)];
        else
            I_Ratio_Pos = [I_Ratio_Pos,NaN];
        end
        
    end
    [~,Length_Index] = sort(Cell_Length);
    Cell_Length = Cell_Length(Length_Index);
    Intensity = Intensity(:,Length_Index);
    
    imagesc(1:numel(Cell_Length),xx,Intensity);
    colormap(map);
    caxis([0.4,1]);
%     xlabel(['Cell Length (n = ' sprintf('%3d',numel(C)) ')']);
    ylabel({'Position along','the cell length (\mum)'});
    set(gca,'FontSize',Label_Size);
    set(gca,'TickDir','out');
    set(gca,'box','off');
%     set(gca,'xtick',(numel(Cell_Length)+1)/2);
    if Show_Lowest_Pt
        hold on;
        scatter(1:numel(Cell_Length),I_Ratio_Pos,30,'ko','filled');
    end
    
    median_index = find(Cell_Length>Middle_IRatio_Length,1);
    hold on;
    plot([median_index,median_index],[-Max_Length/2,Max_Length/2],'LineWidth',2,'Color',[1,0,0],'LineStyle','--');
    h = gca;
    xtickformat('%.1f');
    ytickformat('%.1f');
    h.LineWidth = 2;
    h.YAxis.MinorTick = 'on';
    h.YAxis.MinorTickValues = -6:0.5:6;
%     h.XTick = median_index;
%     h.XTickLabel = {['median=' num2str(round(median(Cell_Length),2))]};
    h.XTick = [];
    h.TickLength = [0.03,0.01];
    colorbar('Ticks',[0.4 0.6 0.8 1],...
            'TickLabels',{'0.4\downarrow','0.6','0.8','1'},...
            'TickLabelInterpreter','tex');
end