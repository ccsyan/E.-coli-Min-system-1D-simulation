function display_ind(C,destination,type,rewrite)
sep_num = 9;
% set to approximate to 16:9 and leave one for the legend
M = ceil(sqrt(sep_num)/sqrt(16/9));
N = ceil( (sep_num)/M );
disp_arr = 1:9;

k=1;
for i=1:sep_num:numel(C)
    if rewrite || exist([destination num2str(k) '.jpg'])==0
        F = figure('units','normalized','outerposition',[0 0.05 .99 .95],'visible','off');
        for j=1:sep_num
            if i+j-1 <=numel(C)
                subplot(M,N,j);
                if type==2 
                    C(i+j-1).draw_ufit;
                elseif type==1
                    C(i+j-1).draw_mean;
                elseif type==0
                    C(i+j-1).draw_nfit;
                end
            end
        end
        print(F,[destination num2str(k) '.jpg'],'-djpeg','-r300');
    end
    k=k+1;
end
end