clear all

t = now;
fprintf(1,'%s\n',repmat('=',1,80));
fprintf(1,'%40s\n',"B Step");
fprintf(1,'%s\n',repmat('=',1,80));
fprintf(1,'\t Start : \t%s',datestr(t,'HH:MM:SS'));

addpath('src/')
read_root = 'raw_data/';
save_root = 'result/';
figure_root = [save_root 'figure/'];
mat_root = 'mat_data/';
summary_root = 'summary_data/';
%Set font name for figures
set(0,'DefaultAxesFontName', 'Arial')
set(0,'DefaultTextFontName', 'Arial')

%read the file
file = dir([read_root '*.xlsx']);

Title_Char_Num = [0,0];
charnum = 0;
for ind = 1:numel(file)
    clear C
    filename = [read_root file(ind).name];
    name = file(ind).name(1:find(file(ind).name=='.',1,'last')-1);
    
    fprintf(1,repmat('\b',1,sum(Title_Char_Num)));
    fprintf(1,repmat('\b',1,charnum));
    Title_Char_Num(1) = fprintf(1,'\n%s\n',repmat('=',1,60));
    Title_Char_Num(2) = fprintf(1,'File %3d / %3d:    %s \n',ind,numel(file),name);

    [values,txt]=xlsread(filename,2);
    [values2,~] = xlsread(filename,1);
    txt = txt(2:end,:);
    num_particle = size(values,2)/4;
    C(num_particle) = particles;
    
    
    charnum =0;
    for i =1:num_particle
        index = (i-1)*4;
        fprintf(1,repmat('\b',1,charnum));
        charnum = fprintf(1,'\titer= \t%d/%d\t cell num = %d\n ',i,num_particle,values(1,index+1));
        
        %read file
        C(i).cell_num = values(1,index+1);
        C(i).length = values2(values2(:,1)==C(i).cell_num,2);
        time_stamp_txt = string(char(txt{:,index+2}));
        repeat_str =extractAfter(time_stamp_txt(2),strfind(time_stamp_txt(2),'(')-1);
        repeat_str = erase(repeat_str," ");
        time_stamp_txt = erase(time_stamp_txt,repeat_str);
        time_stamp_val = num2str(values(:,index+2));
        time_stamp_val(time_stamp_val=='a' | time_stamp_val=='N')=' ';
        time_stamp = str2num(char(strcat(time_stamp_txt,time_stamp_val)));
        
        A2=string(char(txt{:,index+3}));
        A1 = num2str(values(:,index+3));
        A1(A1=='a' | A1=='N')=' ';
        position=str2num(char(strcat(A1,A2)));
        B2 = string(char(txt{:,index+4}));
        B1 = num2str(values(:,index+4));
        B1(B1=='a' | B1=='N')=' ';
        intensity = str2num(char(strcat(B1,B2)));
        
        Temp_Intensity = sortrows([time_stamp, position,intensity],[1,2]);
        minIntensity = min(Temp_Intensity(:,3));
        Temp_Intensity(:,3) = (Temp_Intensity(:,3)-minIntensity);
        
        C(i).intensity = Temp_Intensity;
        C(i).min_intensity = minIntensity;
        C(i) = C(i).cal_interp;
        C(i) = C(i).cal_sep;
        C(i) = C(i).cal_func;
        C(i) = C(i).cal_I_ratio;
    end
    save([mat_root name '.mat'],'name','C');
end

fprintf(1,repmat('\b',1,sum(Title_Char_Num)));
fprintf(1,repmat('\b',1,charnum));
fprintf(1,'\t End : \t%s\t Lapsed Time : \t%s\n',datestr(now,'HH:MM:SS'),datestr(now-t,'HH:MM:SS'));