clear all
warning( 'off', 'MATLAB:xlswrite:AddSheet' ) ;

set(0,'DefaultAxesFontName', 'Arial')
set(0,'DefaultTextFontname', 'Arial')
Line_Width =3;
Label_Size = 27;


addpath('src/')
read_root = 'raw_data/';
save_root = 'result/';
mat_root = 'mat_data/';
summary_root = 'summary_data/';
%Set font name for figures
set(0,'DefaultAxesFontName', 'Arial')
set(0,'DefaultTextFontName', 'Arial')

%read the file
file = dir([mat_root '*.mat']);

output_filename = 'result.xlsx';

for ind = 1:numel(file)
% for ind = 1
    clear C
    load([mat_root file(ind).name]);
    filename = file(ind).name(1:end-4);
    num = numel(C);
    result = zeros(num,4);
    for i = 1:num
        result(i,1) = C(i).length;
        result(i,2) = C(i).I_max;
        result(i,3) = C(i).I_min;
        result(i,4) = C(i).I_min/C(i).I_max;
    end
    xlswrite(output_filename,{'Cell Length','I_max','I_min','I_min/I_max'},filename,'A1');
    xlswrite(output_filename,result,filename,'A2');
end