clear all

addpath('src/')
read_root = 'raw_data/';
save_root = 'result/';
figure_root = [save_root 'figure/'];
mat_root = 'mat_data/';
summary_root = 'summary_data/';

file = dir([read_root '*.xlsx']);

mkfolders('',{save_root,mat_root,summary_root});
mkfolders(figure_root,{'I_Ratio','Mean_Plot','Standing_Wave'});
% mkfolders('',{'Simulation'});
for ind = 1:numel(file)
    filename = [read_root file(ind).name];
    name = file(ind).name(1:find(file(ind).name=='.',1,'last')-1);
    mkfolders([save_root name '/'],{'Mean_plots','Normalized_Position_plots','UnNormalized_Position_plots'});
end