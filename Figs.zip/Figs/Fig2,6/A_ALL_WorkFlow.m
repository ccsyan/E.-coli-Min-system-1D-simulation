%Run this file to get all things done.

A_Create_Folders;
B_read_file_to_mat;
C_output_individual_file_and_figures2&6;
