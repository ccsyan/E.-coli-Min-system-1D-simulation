addpath('src/')
read_root = 'raw_data/';
save_root = 'result/';
%Set font name for figures
set(0,'DefaultAxesFontName', 'Arial')
set(0,'DefaultTextFontName', 'Arial')
LineWidth =5;
L = 3;
xx = 0:0.05:1;
x_peak = [0.15,0.85];
f = @(x,peak,lambda) exp(-lambda.*abs(x-peak));
y_left = f(xx,x_peak(1),L);
y_right = f(xx,x_peak(2),L);
x_mid = 0.5;
y_mid = f(x_mid,x_peak(1),L);
f2=figure('visible','on');% = figure('visible','off');
plot(xx,y_left,'b','LineWidth',LineWidth);
ylim([0,2]);
set(gca,'FontSize',20);
set(gca,'YTick',[y_mid,1]);
set(gca,'XTick',[x_peak(1),x_mid,x_peak(2)]);
set(gca,'XTickLabel',["x_1","x_{min}","x_2"]);
set(gca,'YTickLabel',["I_{min}","I_{max}"]);
xlabel('{\it Position}','FontSize',30);
ylabel('{\it Intensity}','FontSize',30);
h = gca;
h.LineWidth = 2;
h.TickDir = 'both';
h.TickLength = [0.05,0.01];
set(gca,'box','off');
hold on;
plot(xx,y_right,'b','LineWidth',LineWidth);
plot([x_peak(1),x_peak(1)],[0,1],'LineStyle','--','Color',[1,0,0,0.5],'LineWidth',LineWidth);
plot([x_peak(2),x_peak(2)],[0,1],'LineStyle','--','Color',[1,0,0,0.5],'LineWidth',LineWidth);
plot([0,x_peak(2)],[1,1],'LineStyle','--','Color',[1,0,0,0.5],'LineWidth',LineWidth);

plot([x_mid,x_mid],[0,y_mid],'LineStyle','--','Color',[1,0,0],'LineWidth',LineWidth);
plot([0,x_mid],[y_mid,y_mid],'LineStyle','--','Color',[1,0,0],'LineWidth',LineWidth);

text(0.05,1.6,'${\it I_{Ratio}=\frac{m_{min}}{m_{max}}}$','FontSize',50,'Interpreter','latex');
print(f2,[save_root 'figure/Demo1.jpg'],'-djpeg','-r300');