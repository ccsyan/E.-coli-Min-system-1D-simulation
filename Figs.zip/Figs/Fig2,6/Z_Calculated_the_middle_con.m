clear all
warning( 'off', 'MATLAB:xlswrite:AddSheet' ) ;
% particle = 66.246 + 491.78 length
set(0,'DefaultAxesFontName', 'Arial')
set(0,'DefaultTextFontname', 'Arial')
Line_Width =3;
Label_Size = 25;


addpath('src/')
read_root = 'raw_data/';
save_root = 'result/';
mat_root = 'mat_data/';
summary_root = 'summary_data/';
%Set font name for figures
set(0,'DefaultAxesFontName', 'Arial')
set(0,'DefaultTextFontName', 'Arial')

%read the file
file = dir([mat_root '*.mat']);

output_filename = 'result_total_intensity.xlsx';

for ind = 1:numel(file)
% for ind = 1
    clear C
    load([mat_root file(ind).name]);
    filename = file(ind).name(1:end-4);
    num = numel(C);
    result = zeros(num,3);
    for i = 1:num
        result(i,1) = C(i).length;
        [~,mid_inten] = cal_middle_total_intensity(C(i).intensity,0.1/C(i).length);
        result(i,2) = mean(mid_inten(1:20));
        [~,total_inten] = cal_middle_total_intensity(C(i).intensity,0.5);
        result(i,3) = mean(total_inten(1:20));
    end
    f =  figure('visible','off');
    x = result(:,1);
    y = result(:,2)./result(:,3);
    scatter(x,y,'filled','MarkerFaceColor',[0 0.5 0.5],'MarkerEdgeColor','b');
    mdl = fitlm(x,y);
    min_max = [min(x);max(x)];
    hold on;
    plot(min_max,mdl.predict(min_max),'r','LineWidth',4);
    Median_Length = median(x);
    Mdl_Median = mdl.predict(Median_Length);
    plot([Median_Length Median_Length],[0,Mdl_Median],'k--','LineWidth',Line_Width);
    plot([0 Median_Length],[Mdl_Median,Mdl_Median],'k--','LineWidth',Line_Width);
    text(Median_Length + 0.2,0.1,sprintf('%.3f',Median_Length),'Color','black','FontSize',Label_Size);
    
    title(filename);
    xlabel('cell length');
    ylabel('Intensity ratio at midcell');
    set(gca,'FontSize',Label_Size);
    
    h = gca;
    h.LineWidth = Line_Width;
    if contains(filename,'�G')
        h.XLim = [0,6];
        text(Median_Length/2,Mdl_Median -0.03,sprintf('%.3f',Mdl_Median),'Color','black','FontSize',Label_Size,'HorizontalAlignment','center');
    else
        h.XLim = [1,6];
        text((Median_Length+1)/2,Mdl_Median -0.03,sprintf('%.3f',Mdl_Median),'Color','black','FontSize',Label_Size,'HorizontalAlignment','center');
    end
    h.YLim = [0,0.3];
    print(f,[save_root 'figure/Total_Intensity/' filename '.jpg'],'-djpeg','-r300');
    
    xlswrite(output_filename,{'Cell Length','+-100nm','total'},filename,'A1');
    xlswrite(output_filename,result,filename,'A2');
end