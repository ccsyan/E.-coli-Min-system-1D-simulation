clear all
warning( 'off', 'MATLAB:xlswrite:AddSheet' ) ;

t = now;
fprintf(1,'%s\n',repmat('=',1,80));
fprintf(1,'%40s\n',"C Step");
fprintf(1,'%s\n',repmat('=',1,80));
fprintf(1,'\t Start : \t%s',datestr(t,'HH:MM:SS'));

addpath('src/')
read_root = 'raw_data/';
save_root = 'result/';
mat_root = 'mat_data/';
summary_root = 'summary_data/';
%Set font name for figures
set(0,'DefaultAxesFontName', 'Arial')
set(0,'DefaultTextFontName', 'Arial')

Customize_Levels = ["0.416_ glucose","0.208_ glucose","0_ glucose","0.368_ glycerol",...
                    "0.184_ glycerol","0_ glycerol","0.703_ acetate"];
                
%rewrite = 1 => rewrite all individual files no matter it already exist or
%               not.
rewrite = 0;
Lowest_Ratio_Excel_Rewrite = 0;


%read the file
file = dir([mat_root '*.mat']);

Lowest_Ratio_Table = cell2table(cell(0,5),'VariableNames',...
                        {'Name','First_Type','Mutant_Type','Half_Ratio','Median_Ratio'});
Summary_Table = cell2table(cell(0,2),'VariableNames',...
                        {'Name','Cell_Number'});
                    
Title_Char_Num = [0,0];
charnum = 0;

for ind = 1:numel(file)
    clear C
    load([mat_root file(ind).name]);
    
    fprintf(1,repmat('\b',1,sum(Title_Char_Num)));
    fprintf(1,repmat('\b',1,charnum));
    Title_Char_Num(1) = fprintf(1,'\n%s\n',repmat('=',1,60));
    Title_Char_Num(2) = fprintf(1,'Start %3d / %3d:    %s \n',ind,numel(file),name);
    
    if contains(name,'rpoS')
        First_Type = find(strcmp(name(1:end-6),Customize_Levels));
        Mutant_Type = 'rpoS';
    else
        First_Type = find(strcmp(name(1:end-3),Customize_Levels));
        Mutant_Type = 'wt';
    end
    
    num_particle = numel(C);
    crest_dist = zeros(num_particle,2);
    cell_number = zeros(num_particle,1);
    lambda = zeros(num_particle,3);
    I_ratio = zeros(num_particle,2);
    
    for i = 1:numel(C)
        cell_number(i) = C(i).cell_num;
        lambda(i,1) = C(i).length;
        lambda(i,2) = C(i).normal_lambda;
        lambda(i,3) = C(i).unnormal_lambda;
        I_ratio(i,1) = C(i).length;
        I_ratio(i,2) = C(i).I_ratio;
        crest_dist(i,1) = C(i).length;
        crest_dist(i,2) = 1-diff(C(i).crest);
    end
    
    display_ind(C,[save_root name '/UnNormalized_Position_plots/'],2,rewrite);
    display_ind(C,[save_root name '/Mean_plots/'],1,rewrite);
    display_ind(C,[save_root name '/Normalized_Position_plots/'],0,rewrite);
    
    %Lowest Ratio Plots
    f2=figure('visible','off');
    [Lowest_Ratio_Statistics] = Draw_Exp_Decay_Fit(I_ratio);
    title(name);
    print(f2,[save_root 'figure/I_Ratio/' name '.jpg'],'-djpeg','-r300');
    
    Lowest_Ratio_Table = [Lowest_Ratio_Table;[name,First_Type,Mutant_Type,Lowest_Ratio_Statistics]];
    Summary_Table = [Summary_Table;{name,numel(C)}];
    
    if Lowest_Ratio_Excel_Rewrite %I ratio to excel
        T2= table(cell_number,round(I_ratio(:,1),4),round(I_ratio(:,2),4),...
             'VariableNames',...
             {'Cell_number','length','Lowest_Ratio'});
        writetable(T2,[summary_root 'I_ratio.xlsx'],'Sheet',name,'Range','A1');
    end
    
    %Mean Plots
    f = figure('visible','off');
    mean_plot(C,false,Lowest_Ratio_Statistics{1}(1));
    title(name);
    print(f,[save_root 'figure/Mean_Plot/' name '.jpg'],'-djpeg','-r300');
    
    close all hidden;
end

writetable(Summary_Table,[summary_root 'Summary.xlsx'],'Range','A1');

Lowest_Ratio_Table = sortrows(Lowest_Ratio_Table,[2,3]);
save([summary_root 'Lowest_Ratio.mat'],'Lowest_Ratio_Table');

fprintf(1,repmat('\b',1,sum(Title_Char_Num)));
fprintf(1,repmat('\b',1,charnum));
fprintf(1,'\t End : \t%s\t Lapsed Time : \t%s\n',datestr(now,'HH:MM:SS'),datestr(now-t,'HH:MM:SS'));