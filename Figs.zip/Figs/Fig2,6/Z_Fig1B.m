mat_root = 'mat_data/';
%read the file
file = dir([mat_root '*.mat']);
clear C
load([mat_root file(1).name]);

first=C(2);
set(0,'DefaultAxesFontName', 'Arial')
set(0,'DefaultTextFontname', 'Arial')
Label_Size = 28;
Line_Width = 3;
Red_color = [0.827 0.51 0.518];%#d38284
Blue_color = [0.392 0.573 0.663];%#6492A9
cmap = [Red_color;Red_color;0 0 0;Blue_color;Blue_color];
Intensity = first.interp_intensity;
Intensity(:,3) = Intensity(:,3)+first.min_intensity;
f = figure('Renderer', 'painters', 'Position', [10 10 1300 450]);
subplot(3,1,1);
grid = [0.1,0.25,0.5,0.75,0.9];
LineStyleGrid = ["-" "--" "-" "--" "-"];
for i = 1:5
    hold all;
    temp = Intensity(Intensity(:,2)==grid(i),:);
    display_name = sprintf('%.2f',temp(1,2));
    plot(temp(:,1)*12,temp(:,3),'Color',cmap(i,:),'DisplayName',display_name,'LineWidth',Line_Width,'LineStyle',LineStyleGrid(i));
%         fprintf(1,'%.2f: %d\n',temp(1,2),color_index);
end
legend('off');
set(gca,'FontSize',Label_Size);
h = gca;
h.YLim = [219,281];
h.LineWidth = Line_Width;
h.XTick = 0:100:600;
h.YTick = 220:30:280;
title('      Length: 1.833 \mum  Period: 46\pm16 s','FontSize',20)
h.TitleHorizontalAlignment = 'left';
%text(20,290,'Length: 1.833 \mu m  Period:46\pm16 s','FontSize',20)

subplot(3,1,2);
second=C(63);
set(0,'DefaultAxesFontName', 'Arial')
set(0,'DefaultTextFontname', 'Arial')
cell_num = second.cell_num;
Red_color = [0.827 0.51 0.518];%#d38284
Blue_color = [0.392 0.573 0.663];%#6492A9
cmap = [Red_color;Red_color;0 0 0;Blue_color;Blue_color];
Intensity = second.interp_intensity;
Intensity(:,3) = Intensity(:,3)+second.min_intensity;

for i = 1:5
    hold all;
    temp = Intensity(Intensity(:,2)==grid(i),:);
    display_name = sprintf('%.2f',temp(1,2));
    plot(temp(:,1)*12,temp(:,3),'Color',cmap(i,:),'DisplayName',display_name,'LineWidth',Line_Width,'LineStyle',LineStyleGrid(i));
%         fprintf(1,'%.2f: %d\n',temp(1,2),color_index);
end
%legend('-DynamicLegend');
lgd = legend("10%","25%","50%","75%","90%");
set(gca,'FontSize',Label_Size);
h = gca;
h.LineWidth = Line_Width;
h.XTick = 0:100:600;
h.YTick = 250:50:300;
ylabel('Intensity (au)');
title('      Length: 2.836 \mum  Period: 47\pm7 s','FontSize',20)
h.TitleHorizontalAlignment = 'left';
%text(20,315,'Length: 2.836 \mu m  Period:47\pm7 s','FontSize',20)

subplot(3,1,3);
third=C(128);
set(0,'DefaultAxesFontName', 'Arial')
set(0,'DefaultTextFontname', 'Arial')
cell_num = third.cell_num;
Red_color = [0.827 0.51 0.518];%#d38284
Blue_color = [0.392 0.573 0.663];%#6492A9
cmap = [Red_color;Red_color;0 0 0;Blue_color;Blue_color];
Intensity = third.interp_intensity;
Intensity(:,3) = Intensity(:,3)+third.min_intensity;

for i = 1:5
    hold all;
    temp = Intensity(Intensity(:,2)==grid(i),:);
    display_name = sprintf('%.2f',temp(1,2));
    plot(temp(:,1)*12,temp(:,3),'Color',cmap(i,:),'DisplayName',display_name,'LineWidth',Line_Width,'LineStyle',LineStyleGrid(i));
%         fprintf(1,'%.2f: %d\n',temp(1,2),color_index);
end
legend('off');
set(gca,'FontSize',Label_Size);
h = gca;
h.LineWidth = Line_Width;
h.XTick = 0:100:600;
h.YTick = 220:20:240;
title('      Length: 4.043 \mum  Period: 50\pm6 s','FontSize',20)
h.TitleHorizontalAlignment = 'left';
%text(20,255,'Length: 4.043 \mu m  Period:50\pm6 s','FontSize',20)

set(gca, 'FontName', 'Arial');
print(f,'Fig1B.tif','-dtiffn');