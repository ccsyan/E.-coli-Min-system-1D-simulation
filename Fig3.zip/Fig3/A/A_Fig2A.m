%%addpath('src/')
file = dir('raw_data/*.xlsx');
ind  =1;
filename = ['raw_data/' file(ind).name];
name = file(ind).name(1:find(file(ind).name=='.',1,'last')-1);
[values,~]=xlsread(filename,1);
values(~any(~isnan(values),2),:)=[];

x = values(:,2);
y = values(:,8);
yhat = zeros(numel(y),1);
y2 = values(:,9);
y2hat = zeros(numel(y2),1);
lab_bec = values(:,1);
bec_unique = [54,58,57];
for i = 1:numel(bec_unique)
    bec = bec_unique(i);
    model = fitlm(x(lab_bec==bec),y(lab_bec==bec));
    yhat(lab_bec==bec) = predict(model,x(lab_bec==bec));
    model2 = fitlm(x(lab_bec==bec),y2(lab_bec==bec));
    y2hat(lab_bec==bec) = predict(model2,x(lab_bec==bec));
end


set(0,'DefaultAxesFontName', 'Arial')
set(0,'DefaultTextFontname', 'Arial')
Label_Size = 30;
Line_Width = 6;
Point_Size = 170;
alpha = 0.05;

f = figure('Renderer', 'painters', 'Position', [10 10 540 460]);
yyaxis left
scatter(x(lab_bec~=57),y2(lab_bec~=57),Point_Size,'MarkerEdgeColor',[0, 0.5, 0],'LineWidth',3);
hold on;
for i = 1:(numel(bec_unique)-1)
    bec = bec_unique(i);
    plot(x(lab_bec==bec),y2hat(lab_bec==bec),'Color',[0, 0.5, 0],'LineStyle','-','LineWidth',Line_Width, 'Marker', 'none');
end
bec = 57;
scatter(x(lab_bec==57),y2(lab_bec==57),Point_Size,'MarkerEdgeColor',[0.3, 0.8, 0.3],'LineWidth',3);
plot(x(lab_bec==bec),y2hat(lab_bec==bec),'Color',[0.3, 0.8, 0.3],'LineStyle','-','LineWidth',Line_Width, 'Marker', 'none');


set(gca,'ycolor',[0, 0.5, 0]);
ylabel('Unit intensity (a.u./\mum^2)');
ylim([0.5 1.5]*10^5);
h = gca;
h.YTick = 0.5*10^5:0.25*10^5:1.5*10^5;
h.YAxis(2).SecondaryLabel.Position = [210,2.05e+05 1];

yyaxis right

scatter(x(lab_bec~=57),y(lab_bec~=57),Point_Size,'d','MarkerEdgeColor',[1,0, 0],'LineWidth',3);
hold on;
for i = 1:(numel(bec_unique)-1)
    bec = bec_unique(i);
    plot(x(lab_bec==bec),yhat(lab_bec==bec),'Color',[1,0, 0],'LineStyle','-','LineWidth',Line_Width, 'Marker', 'none');
end
bec = 57;
scatter(x(lab_bec==57),y(lab_bec==57),Point_Size,'d','MarkerEdgeColor',[0.6,0.3,0.3],'LineWidth',3);
plot(x(lab_bec==bec),yhat(lab_bec==bec),'Color',[0.6,0.3,0.3],'LineStyle','-','LineWidth',Line_Width, 'Marker', 'none');


ylabel('Intensity (a.u.)');
set(gca,'ycolor','red');
set(gca,'FontSize',Label_Size);
set(gca,'TickDir','out');
set(gca,'TickLength',[0.03, 0.01])
set(gca,'Box','off');
xlim([0,210]);

h = gca;
h.LineWidth = Line_Width;
h.XTick = 0:60:210;
h.XAxis.MinorTick = 'on';
h.XAxis.MinorTickValues = 0:30:210;
h.YAxis(1).SecondaryLabel.Position = [-45,1.535e+05 1];
set(gca, 'OuterPosition', [0,0,1,0.95]);
set(gca, 'color', 'none');
xlabel('Time(min)');
print(f,'Fig_2A.tif','-dtiffn');
print(f,'Fig_2A.jpeg','-djpeg');
%exportgraphics(f,'Fig_2A.pdf',...
%    'BackgroundColor','none')
