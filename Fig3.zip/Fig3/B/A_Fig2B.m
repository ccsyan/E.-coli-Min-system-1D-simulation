%%addpath('src/')
file = dir('raw_data/*.xlsx');
ind  =1;
filename = ['raw_data/' file(ind).name];
name = file(ind).name(1:find(file(ind).name=='.',1,'last')-1);
[values,~]=xlsread(filename,1);
values(~any(~isnan(values),2),:)=[];
[values2,~] = xlsread(filename,2);
values2(~any(~isnan(values2),2),:)=[];

time_index = values(:,1);
time_size = numel(time_index);
num_of_cell = (size(values,2)-1)/2;
result = [];
for i = 1:(num_of_cell)
    temp = zeros(time_size,4);
    temp(:,1) = time_index; %Time
    temp(:,2) = values(:,i*2); %Length
    temp(:,4) = values(:,i*2+1);
    temp(:,5) = values2(:,i*2+1);
    temp(any(isnan(temp),2),:)=[];
    temp(:,3) = temp(:,2) - temp(1,2); %Delta Length
    temp(:,6) = [NaN; diff(temp(:,3))./diff(temp(:,1))];
    result = [result;temp];
end


%% Time
result2 = result(result(:,1)<=90,:);
set(0,'DefaultAxesFontName', 'Arial')
set(0,'DefaultTextFontname', 'Arial')
Label_Size = 28;
Line_Width = 5;
alpha = 0.05;
x = result(:,1);
y = result(:,4);
mdl = fitlm(x,y);
xhat = linspace(0,90,100)';

[yhat,yci] = predict(mdl,xhat,'Alpha',alpha);
f = figure('Renderer', 'painters', 'Position', [10 10 540 400]);
yyaxis right
plot(xhat,yhat,'Color','red','LineStyle','-','LineWidth',Line_Width);
hold on;
plot(xhat,yci,'Color','red','LineStyle','--','LineWidth',Line_Width);

set(gca,'ycolor','r');
ylabel('Molecule');

yyaxis left
y2 = result(:,5);
mdl2 = fitlm(x,y2);

[yhat2,yci2] = predict(mdl2,xhat,'Alpha',alpha);
plot(xhat,yhat2,'Color',[0, 0.5, 0],'LineStyle','-','LineWidth',Line_Width);
hold on;
plot(xhat,yci2,'Color',[0, 0.5, 0],'LineStyle','--','LineWidth',Line_Width);

ylabel('Molecule/\mum^2');
set(gca,'ycolor',[0, 0.5, 0]);
set(gca,'FontSize',Label_Size);
set(gca,'TickDir','out');
set(gca,'TickLength',[0.03, 0.01])
set(gca,'Box','off');
xlim([0,90]);
hold on;
plot([37.34,37.34],[1140,1200],'Color','black','LineStyle','-.','LineWidth',Line_Width);
ylim([1140,1200]);
h = gca;
h.LineWidth = Line_Width;
h.XTick = 0:30:90;
h.XAxis.MinorTick = 'on';
h.XAxis.MinorTickValues = 0:15:90;


annotation('textbox',[.32 .42 .5 .5],'String',{'37.34 min','2205 molecule'},'FitBoxToText','on','FontSize',Label_Size-5,'BackgroundColor','white');
xlabel('Time(min)');
print(f,'Fig_2B.tif','-dtiffn');